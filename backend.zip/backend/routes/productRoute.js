import express from 'express';
import { addProduct, listProducts, removeProduct, singleProduct } from '../controllers/productController.js';
import adminAuth from '../middleware/adminAuth.js';
import upload from '../middleware/multer.js';

const productRouter = express.Router();

// Route to add a product (Admin only)
productRouter.post('/add', adminAuth, upload.fields([
    { name: 'image1', maxCount: 1 },
    { name: 'image2', maxCount: 1 },
    { name: 'image3', maxCount: 1 },
    { name: 'image4', maxCount: 1 }
]), addProduct);

// Route to remove a product (Admin only)
productRouter.post('/remove', adminAuth, removeProduct);

// Route to get a single product by ID
productRouter.get('/single', singleProduct);

// Route to list all products
productRouter.get('/list', listProducts);

export default productRouter;
