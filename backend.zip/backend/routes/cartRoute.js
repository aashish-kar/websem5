import express from 'express';
import { addToCart, getUserCart, updateCart } from '../controllers/cartController.js';
import authUser from '../middleware/auth.js';

const cartRouter = express.Router();

// Fix: Ensure the correct route for getting cart items
cartRouter.get('/:userId', authUser, getUserCart); // Route must match the frontend request

cartRouter.post('/add', authUser, addToCart);
cartRouter.put('/update', authUser, updateCart);

export default cartRouter;
