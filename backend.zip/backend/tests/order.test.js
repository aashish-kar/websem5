// import * as chai from "chai";
// import chaiHttp from "chai-http";
// import app from "../server.js";

// chai.use(chaiHttp);
// const { expect } = chai;

// describe("Order API Tests", function () {
//     it("Should fetch all orders", async function () {
//         const res = await chai.request(app).get("/api/orders");
//         expect(res).to.have.status(200);
//     });

//     it("Should create an order", async function () {
//         const res = await chai.request(app).post("/api/orders").send({
//             items: [{ productId: "123", quantity: 2 }],
//         });

//         expect(res).to.have.status(201);
//     });

//     it("Should fetch an order by ID", async function () {
//         const res = await chai.request(app).get("/api/orders/123");
//         expect(res).to.have.status(404);
//     });

//     it("Should update order status", async function () {
//         const res = await chai.request(app).put("/api/orders/123").send({
//             status: "Delivered",
//         });

//         expect(res).to.have.status(404);
//     });
// });
