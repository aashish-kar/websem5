const chai = await import("chai"); // ✅ Use `await import()` for ES modules
const chaiHttp = await import("chai-http");
const mongoose = await import("mongoose");
import userModel from "../models/userModel.js";
import app from "../server.js";

// ✅ Properly apply Chai HTTP middleware
chai.default.use(chaiHttp.default);
const { expect } = chai.default;
const request = chai.default.request;

let testUser = {
    name: "Test User",
    email: "testuser@example.com",
    password: "TestPass123",
};

let token; // Store JWT token after login

describe("🔍 User API Tests", function () {
    before(async function () {
        await userModel.deleteMany({});
    });

    it("✅ Should register a new user", function (done) {
        request(app)
            .post("/api/user/register")
            .send(testUser)
            .end((err, res) => {
                expect(res).to.have.status(201);
                expect(res.body).to.have.property("success", true);
                expect(res.body).to.have.property("token");
                expect(res.body.user).to.have.property("_id");
                testUser._id = res.body.user._id;
                done();
            });
    });

    it("✅ Should log in an existing user", function (done) {
        request(app)
            .post("/api/user/login")
            .send({ email: testUser.email, password: testUser.password })
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body).to.have.property("success", true);
                expect(res.body).to.have.property("token");
                token = res.body.token;
                done();
            });
    });

    it("❌ Should not log in with wrong password", function (done) {
        request(app)
            .post("/api/user/login")
            .send({ email: testUser.email, password: "WrongPass123" })
            .end((err, res) => {
                expect(res).to.have.status(401);
                expect(res.body).to.have.property("success", false);
                expect(res.body.message).to.equal("Invalid credentials");
                done();
            });
    });

    it("✅ Should log in as admin", function (done) {
        request(app)
            .post("/api/user/admin")
            .send({ email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD })
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body).to.have.property("success", true);
                expect(res.body).to.have.property("token");
                done();
            });
    });

    it("❌ Should not log in as admin with wrong credentials", function (done) {
        request(app)
            .post("/api/user/admin")
            .send({ email: "wrong@example.com", password: "wrongpassword" })
            .end((err, res) => {
                expect(res).to.have.status(401);
                expect(res.body).to.have.property("success", false);
                expect(res.body.message).to.equal("Invalid admin credentials");
                done();
            });
    });

    it("✅ Should fetch user profile", function (done) {
        request(app)
            .get("/api/user/profile")
            .set("Authorization", `Bearer ${token}`)
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body).to.have.property("success", true);
                expect(res.body).to.have.property("user");
                expect(res.body.user.email).to.equal(testUser.email);
                done();
            });
    });

    it("❌ Should not fetch profile without token", function (done) {
        request(app)
            .get("/api/user/profile")
            .end((err, res) => {
                expect(res).to.have.status(401);
                expect(res.body).to.have.property("success", false);
                expect(res.body.message).to.equal("Unauthorized access - No token provided");
                done();
            });
    });

    it("✅ Should update user profile", function (done) {
        request(app)
            .put("/api/user/profile")
            .set("Authorization", `Bearer ${token}`)
            .send({ name: "Updated User" })
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body).to.have.property("success", true);
                expect(res.body.user.name).to.equal("Updated User");
                done();
            });
    });

    it("✅ Should delete user account", function (done) {
        request(app)
            .delete("/api/user/profile")
            .set("Authorization", `Bearer ${token}`)
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body).to.have.property("success", true);
                done();
            });
    });

    it("❌ Should not fetch profile after deletion", function (done) {
        request(app)
            .get("/api/user/profile")
            .set("Authorization", `Bearer ${token}`)
            .end((err, res) => {
                expect(res).to.have.status(404);
                expect(res.body).to.have.property("success", false);
                expect(res.body.message).to.equal("User not found");
                done();
            });
    });

    after(async function () {
        await mongoose.connection.close();
    });
});
