// import * as chai from "chai";
// import chaiHttp from "chai-http";
// import app from "../server.js";

// chai.use(chaiHttp);
// const { expect } = chai;

// describe("Cart API Tests", function () {
//     it("Should fetch cart items", async function () {
//         const res = await chai.request(app).get("/api/cart");
//         expect(res).to.have.status(200);
//     });

//     it("Should add an item to the cart", async function () {
//         const res = await chai.request(app).post("/api/cart").send({
//             productId: "123",
//             quantity: 1,
//         });

//         expect(res).to.have.status(201);
//     });

//     it("Should remove an item from cart", async function () {
//         const res = await chai.request(app).delete("/api/cart/123");
//         expect(res).to.have.status(404);
//     });

//     it("Should clear the cart", async function () {
//         const res = await chai.request(app).delete("/api/cart");
//         expect(res).to.have.status(200);
//     });
// });
