// import * as chai from "chai"; // ✅ Correct way to import Chai in ES Modules
// import chaiHttp from "chai-http";
// import app from "../server.js"; // ✅ Correct import for `app`

// chai.use(chaiHttp);
// const { expect } = chai;

// describe("Product API Tests", function () {
//     it("Should fetch all products", async function () {
//         const res = await chai.request(app).get("/api/products"); // ✅ Use `app`
//         expect(res).to.have.status(200);
//     });

//     it("Should add a new product", async function () {
//         const res = await chai
//             .request(app)
//             .post("/api/products")
//             .send({
//                 name: "Test Product",
//                 price: 10,
//                 category: "Electronics",
//             });

//         expect(res).to.have.status(201);
//     });

//     it("Should fetch a single product", async function () {
//         const res = await chai.request(app).get("/api/products/123"); // ✅ Use `app`
//         expect(res).to.have.status(404); // Product not found
//     });

//     it("Should delete a product", async function () {
//         const res = await chai.request(app).delete("/api/products/123"); // ✅ Use `app`
//         expect(res).to.have.status(404); // Not found
//     });
// });
