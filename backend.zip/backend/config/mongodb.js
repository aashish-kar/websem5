import mongoose from "mongoose";
import dotenv from "dotenv";  // Import dotenv

dotenv.config();  // Load environment variables

const connectDB = async () => {
    
        const conn = await mongoose.connect(process.env.MONGODB_URI, {
            dbName: "jwelery",  // Set database name separately
        });

        console.log("mongoDB connected");
};

export default connectDB;
