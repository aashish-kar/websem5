import jwt from 'jsonwebtoken';

const authUser = async (req, res, next) => {
    console.log("🔍 Checking token in request headers:", req.headers.authorization);

    const token = req.headers.authorization?.split(" ")[1]; // Extract Bearer token

    if (!token) {
        console.log("❌ No token found in request");
        return res.status(401).json({ success: false, message: 'Unauthorized access - No token provided' });
    }

    try {
        console.log("🔹 Verifying token...");
        const token_decode = jwt.verify(token, process.env.JWT_SECRET);

        console.log("✅ Token verified! User ID:", token_decode.id);
        req.body.userId = token_decode.id; // Attach userId to request body
        next();
    } catch (error) {
        console.log("❌ Token verification failed:", error.message);
        return res.status(401).json({ success: false, message: 'Unauthorized access - Invalid token' });
    }
};

export default authUser;
