import orderModel from "../models/orderModel.js";
import userModel from "../models/userModel.js";

// ✅ Place Order using COD (Cash on Delivery)
const placeOrder = async (req, res) => {
    try {
        const { userId, items, amount, address } = req.body;

        const orderData = {
            userId,
            items,
            address,
            amount,
            paymentMethod: 'COD',
            payment: false,
            date: Date.now()
        };

        const newOrder = new orderModel(orderData);
        await newOrder.save();

        await userModel.findByIdAndUpdate(userId, { cartData: {} });

        res.json({ success: true, message: 'Order Placed' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// ✅ Fetch All Orders for Admin Panel
const allOrders = async (req, res) => {
    try {
        const orders = await orderModel.find().sort({ date: -1 }).populate("userId", "name email");
        res.json({ success: true, orders });
    } catch (error) {
        console.error("Error fetching orders:", error);
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// ✅ Fetch User Orders for Frontend
const userOrders = async (req, res) => {
    try {
        const { userId } = req.params; // Get userId from request

        const orders = await orderModel.find({ userId }).sort({ date: -1 });

        if (!orders.length) {
            return res.json({ success: false, message: "No orders found" });
        }

        res.json({ success: true, orders });
    } catch (error) {
        console.error("Error fetching user orders:", error);
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// ✅ Update Order Status from Admin Panel
const updateStatus = async (req, res) => {
    try {
        const { orderId, status } = req.body;

        await orderModel.findByIdAndUpdate(orderId, { status });

        res.json({ success: true, message: "Order status updated" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

export { allOrders, placeOrder, updateStatus, userOrders };

