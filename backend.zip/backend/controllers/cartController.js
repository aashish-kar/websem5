import productModel from "../models/productModel.js"; // Import Product Model
import userModel from "../models/userModel.js";


// Add products to user cart
const addToCart = async (req, res) => {
    try {
        const { userId, itemId } = req.body;

        // Ensure user exists
        const userData = await userModel.findById(userId);
        if (!userData) {
            return res.status(404).json({ success: false, message: "User not found" });
        }

        // Ensure cartData exists
        let cartData = userData.cartData || {};

        // Update cart quantity
        cartData[itemId] = (cartData[itemId] || 0) + 1;

        // Save updated cart
        await userModel.findByIdAndUpdate(userId, { cartData });
        res.json({ success: true, message: "Item added to cart" });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// Update cart
const updateCart = async (req, res) => {
    try {
        const { userId, itemId, quantity } = req.body;

        // Ensure user exists
        const userData = await userModel.findById(userId);
        if (!userData) {
            return res.status(404).json({ success: false, message: "User not found" });
        }

        // Ensure cartData exists
        let cartData = userData.cartData || {};
        cartData[itemId] = quantity;

        // Save updated cart
        await userModel.findByIdAndUpdate(userId, { cartData });
        res.json({ success: true, message: "Cart updated" });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// Get user cart data
const getUserCart = async (req, res) => {
    try {
        const { userId } = req.params;
        console.log("Fetching cart for user:", userId); // Log User ID

        if (!userId) {
            console.error("Error: No userId provided");
            return res.status(400).json({ success: false, message: "User ID is required" });
        }

        // Check if user exists
        const userData = await userModel.findById(userId);
        if (!userData) {
            console.error("Error: User not found in DB");
            return res.status(404).json({ success: false, message: "User not found" });
        }

        // Ensure cartData exists
        let cartData = userData.cartData || {};
        console.log("Cart Data Retrieved:", cartData);

        if (Object.keys(cartData).length === 0) {
            return res.json({ success: true, cartItems: [] });
        }

        // Fetch product details
        const cartItems = await Promise.all(
            Object.entries(cartData).map(async ([productId, quantity]) => {
                try {
                    const product = await productModel.findById(productId);
                    if (!product) {
                        console.warn(`Product not found for ID: ${productId}`);
                        return null; // Handle deleted products
                    }
                    return { product, quantity };
                } catch (err) {
                    console.error(`Error fetching product for ID ${productId}:`, err);
                    return null;
                }
            })
        );

        const validCartItems = cartItems.filter(item => item !== null);
        console.log("Final Cart Response:", validCartItems);

        res.json({ success: true, cartItems: validCartItems });

    } catch (error) {
        console.error("Unexpected Error in getUserCart:", error);
        res.status(500).json({ success: false, message: "Server error", error: error.message });
    }
};

export { addToCart, getUserCart, updateCart };

